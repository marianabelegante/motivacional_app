package com.example.app_motivacional

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
