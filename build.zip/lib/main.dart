import 'package:flutter/material.dart';
import 'package:app_motivacional/frase_motivacional_app_page.dart';

void main() {
  runApp(MaterialApp(
    home: FraseMotivacionalApp(),
  ));
}

